import {chromium} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/tmp/specimen-benchmark-tools/chrome/opt/google/chrome/chrome',headless:false,args:['--disable-background-timer-throttling','--disable-backgrounding-occluded-windows','--disable-renderer-backgrounding']});
try {
 const cdp=await browser.newBrowserCDPSession();
 const gpu=await cdp.send('SystemInfo.getInfo');
 const page=await browser.newPage();
 const webgl=await page.evaluate(()=>{let g=document.createElement('canvas').getContext('webgl2'),e=g?.getExtension('WEBGL_debug_renderer_info');return {renderer:g?.getParameter(e?e.UNMASKED_RENDERER_WEBGL:g.RENDERER),vendor:g?.getParameter(e?e.UNMASKED_VENDOR_WEBGL:g.VENDOR),timer:!!g?.getExtension('EXT_disjoint_timer_query_webgl2'),dpr:devicePixelRatio};});
 const result={browser:browser.version(),gpu,webgl};
 await writeFile('artifacts/lab-benchmark/gpu.json',JSON.stringify(result,null,2));
 console.log(JSON.stringify({browser:result.browser,devices:gpu.gpu.devices,features:gpu.gpu.featureStatus,webgl},null,2));
} finally {await browser.close();}
