import json, html, math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
results=json.loads((root/'results.json').read_text())
by_label={r['label']:r for r in results}
def esc(v): return html.escape(str(v))
def fmt(v,dp=1): return 'unavailable' if v is None else f'{v:.{dp}f}'
def source(c,r): return f'../performance-overhaul/{r["label"]}/{c["file"]}'
def name(c):
    f=c['file'];level='Level 1' if '__one' in f else 'Level 2' if '__two' in f else 'Level 3'
    room=f.split('-')[-3] if '-warmed-bob-' not in f else '1'
    label=f.replace('run0-__one-','L1 room ').replace('run0-__two-','L2 room ').replace('run0-__three-','L3 room ').replace('-flight.json','')
    return label
rows=[]
main_labels=['lab-long-default-1080','lab-open-safe-minimum-1080','lab-open-safe-standard-1080','lab-background-paused-1080','lab-background-control-1080']
for label in main_labels:
    r=by_label.get(label)
    if not r: continue
    for c in r['captures']:
        if not c['valid']: continue
        f=c['frame'];gpu=c.get('gpu') or {}
        rows.append(f'<tr><td>{esc(label)}</td><td><a href="{source(c,r)}">{esc(name(c))}</a></td><td>{fmt(c["elapsedMs"]/1000)}</td><td>{fmt(f["fps"])}</td><td>{fmt(f["onePercentLow"])}</td><td>{fmt(f["p95"])}</td><td>{fmt(f["p99"])}</td><td>{fmt(f["max"])}</td><td>{fmt(gpu.get("mean"),2)}</td><td>{c["hitches"]["150"]}</td><td>{fmt(c["simulation"]["lostPercent"],2)}%</td></tr>')
long=by_label['lab-long-default-1080'];run=long['runs'][0]
restarts=[]
for rt,label in [('__one','Level 1'),('__two','Level 2'),('__three','Level 3')]:
    points=[p for p in run.get('restarts',[]) if p['name']==rt]
    if not points: continue
    ranges=lambda k: f'{min(p[k] for p in points)}–{max(p[k] for p in points)}'
    heaps=[p['heap']/2**20 for p in points if p.get('heap') is not None]
    restarts.append(f'<tr><td>{label}</td><td>{len(points)}</td><td>{ranges("programs")}</td><td>{ranges("geometries")}</td><td>{ranges("textures")}</td><td>{fmt(min(heaps))}–{fmt(max(heaps))}</td></tr>')
plot_cases=[('lab-long-default-1080','run0-__two-1-flight.json','Entry: background preparation active'),('lab-long-default-1080','run0-__two-1-warmed-bob-flight.json','Same entry after preparation completed'),('lab-background-paused-1080','run0-__two-1-flight.json','Diagnostic: optional background work paused'),('lab-background-control-1080','run0-__two-1-flight.json','Stock control: background preparation enabled again')]
plot_cases=[x for x in plot_cases if x[0] in by_label]
fig,axes=plt.subplots(len(plot_cases),1,figsize=(10,2.2*len(plot_cases)),sharex=True,sharey=True,squeeze=False)
for ax,(label,file,title) in zip(axes[:,0],plot_cases):
    flight=json.loads((root.parent/'performance-overhaul'/label/file).read_text());col={k:i for i,k in enumerate(flight['frameColumns'])}
    raw=flight.get('retainedFrames')
    if raw is None: raw=[r for w in flight['hitchWindows'] for r in w['frames']]
    unique={r[col['sequence']]:r for r in raw};frames=[unique[k] for k in sorted(unique)][1:]
    elapsed=0;t=[];interval=[]
    for r in frames: elapsed+=r[col['deltaMs']]/1000;t.append(elapsed);interval.append(r[col['deltaMs']])
    ax.plot(t,interval,lw=.7,color='#7144b8');ax.axhline(1000/60,ls=':',lw=.8,color='#2d8a65');ax.axhline(150,ls='--',lw=.8,color='#d56743')
    ax.set_title(title,loc='left',fontsize=10);ax.set_ylabel('Frame interval (ms)');ax.set_ylim(0,220);ax.grid(alpha=.15)
axes[-1,0].set_xlabel('Recorded gameplay time (seconds)');fig.tight_layout();fig.savefig(root/'frame-pacing.png',dpi=160);fig.savefig(root/'frame-pacing.svg');plt.close(fig)
invalid=[]
for r in results:
    for c in r['captures']:
        if not c['valid']: invalid.append(f'<li>{esc(r["label"])} / {esc(c["file"])}: {esc("; ".join(c["reasons"]))}. Excluded from performance conclusions.</li>')
warning_count=len(long.get('errors',[]))
paused=by_label.get('lab-background-paused-1080')
paused_text='A paused-background diagnostic was not collected.'
if paused:
    valid=[c for c in paused['captures'] if c['valid']]
    if valid:
        c=valid[0];paused_text=f'Pausing only optional background queue ticks after mandatory startup preparation produced {fmt(c["frame"]["fps"])} FPS, {c["hitches"]["150"]} intervals above 150 ms, and {fmt(c["simulation"]["lostPercent"],2)}% simulation loss in {fmt(c["elapsedMs"]/1000)} seconds. This is a diagnostic override, excluded from stock-game qualification. It does not validate later doorway loading after delaying preparation.'
control=by_label.get('lab-background-control-1080')
if control:
    valid=[c for c in control['captures'] if c['valid']]
    if valid:
        c=valid[0]
        paused_text+=f' Re-enabling background preparation in a fresh stock control reproduced {fmt(c["frame"]["fps"])} FPS, {fmt(c["frame"]["max"])} ms worst frame, {c["hitches"]["150"]} severe hitches, and {fmt(c["simulation"]["lostPercent"],2)}% simulation loss. CPU/GPU means stay small; the preparation-related delivery stalls return.'
body=f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Specimen: assessment-machine benchmark</title><style>body{{font:16px/1.55 system-ui,sans-serif;max-width:1180px;margin:40px auto;padding:0 24px;color:#252331;background:#fcfbff}}h1,h2{{line-height:1.2}}h2{{margin-top:36px}}table{{border-collapse:collapse;font-size:13px;width:100%}}th,td{{border:1px solid #ddd6e7;padding:8px;text-align:left}}th{{background:#eee9f5}}a{{color:#5e34a3}}.scroll{{overflow-x:auto}}img{{max-width:100%;height:auto}}code,pre{{background:#eee9f5;padding:2px 5px}}pre{{padding:16px;overflow:auto}}.note{{padding:15px;border-left:4px solid #8161ad;background:#f0edf5}}small{{color:#595465}}</style>
<h1>Specimen: assessment-machine benchmark</h1><p>21 October 2026 · machine assessment-A · committed build <code>{esc(long['gitSha'])}</code></p>
<p class="note"><strong>The default Minimum hardware profile sustains approximately 60 FPS in the accepted settled samples. Early Level 2 background preparation causes repeatable stalls and should be the first optimisation target.</strong> Initial loading and incomplete Level 1 warmup coverage also merit work. These are measured diagnostic results, not formal completion of the team's seven-scenario qualification protocol.</p>
<h2>Machine and settings</h2><p>Intel Core i3-1220P (10 cores / 12 logical processors), 16 GB class RAM, integrated Intel Alder Lake graphics, i915, Mesa 25.2.8, Ubuntu 24.04.4 / kernel 6.8.0-124-generic. Google Chrome 156.0.8078.47 uses the actual Intel GPU through ANGLE OpenGL ES; GPU timers are supported. Display 1920×1080 at 59.96 Hz; balanced power profile.</p>
<p>The default run uses a <strong>1920×1080 browser viewport with a 1280×720 3D drawing buffer</strong>, effective DPR 0.667, Minimum hardware / Normal, requested render scale 75%, 512-pixel shadow cap, minimum gel mode, antialiasing off. The pixel budget further limits the requested scale. Interface resolution remains native.</p>
<p><a href="machine.json">Machine conditions</a> · <a href="gpu.json">Chrome GPU report</a> · <a href="dist/build-manifest.json">Clean build manifest and asset hashes</a> · <a href="results.json">Full derived measurements</a></p>
<h2>Rubric interpretation</h2><p>The supplied <a href="../../CGV%20Project%20Brief%20%E2%80%94%20Computer%20Graphics%20and%20Visualisation.pdf">project brief</a>, section 6.1 (pages 8–9), says to budget for marking hardware and profile frame time, draw calls, textures, shadows, allocations and disposal. The checklist on page 17 explicitly requires acceptable lab frame rates and stable memory over all three levels. The rubric has no fixed numerical FPS requirement.</p>
<p>Viewing 10%; Control &amp; Playability 10%; 3D Effects 15%; Shaders 10%; Gameplay &amp; Experience 25%; Polish 10%; Innovation 10%; Trailer 10%. Lag is explicitly penalised in Gameplay &amp; Experience and Polish; responsive controls and smooth cameras are also assessed. The repository's proposed 30 FPS floor / 60 FPS aspiration is a planning hypothesis, not an approved marking threshold.</p>
<h2>Validated recordings</h2><p>Collected 24 analyser-valid exports (23 stock-game recordings and one paused-background diagnostic); two death-contaminated exports were excluded. This is broader diagnostic sampling, not 24 completions of the formal qualification scenarios.</p><p>Average FPS is 1000 divided by mean recorded frame interval. The 1% low uses the average of the slowest ceil(1% × N) intervals. Quantiles use the maintained analyser's sorted index floor(N × p). Statistics exclude the first interval that may precede recording. Only complete, focused, visible, drawn, playing-state recordings with native input and body/camera motion are included. “Lost simulation” is time discarded by the game's existing fixed-step safety limits.</p>
<div class="scroll"><table><thead><tr><th>Run</th><th>View / raw export</th><th>Seconds</th><th>Mean FPS</th><th>1% low FPS</th><th>p95 ms</th><th>p99 ms</th><th>Max ms</th><th>Mean GPU ms</th><th>&gt;150 ms</th><th>Lost simulation</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>
<p>The long default captures use repeating short WASD movements, a jump, and pointer-locked mouse turns near authored entry positions. Room 5 corridor views have limited visibility and must not stand in for the full chamber. The safe open-view runs separately stage Bob on the final authored safe deck (local 0,29.46,37) and Goop on a dry sewer bank (46,-10.74,95), use brief body movement and sustained camera turns, and keep ordinary hazards active. They are observation workloads, not complete parkour/combat routes.</p>
<h2>Where optimisation is useful</h2><ol><li><strong>Level 2 background preparation and frame delivery.</strong> The initial long entry capture averages 55.2 FPS but includes five intervals above 150 ms, a 200 ms worst interval, a 7.7 FPS 1% low and 1.85% discarded active simulation time. Mean GPU time is only about 4.0 ms; recorded update/render CPU averages are approximately 0.9/3.2 ms. The matched warmed entry returns to 59.9 FPS without severe hitches or simulation loss. Preparation advances from incomplete to 12/12 configurations as the stalls clear. {esc(paused_text)} Review <a href="../../src/render/CultivationPreparationQueue.ts">CultivationPreparationQueue</a> and <a href="../../src/levels/CultivationLevelRuntime.ts">runtime scheduling</a>: limit speculative compiler work and preserve mandatory first-use/doorway preparation. The exact driver/compositor mechanism is not isolated by these measurements.</li>
<li><strong>Level 1 startup.</strong> Navigation to control consistently takes approximately 29 seconds in the Minimum profile, with about 26 seconds in lighting/presentation preparation. The measured nine warmup steps include both compile waits and resource priming/yields. Profile these separately before reducing work; do not attribute the whole interval to asset download or asynchronous compilation. The long run's Level 2 request-to-enabled-input interval is {fmt(run.get('twoTransitionMs',0)/1000)} seconds; Level 3 is {fmt(run.get('threeTransitionMs',0)/1000)} seconds including its normal seven-second arrival presentation. These local HTTP/instrumented-cache measurements are not LAMP-network loading predictions.</li>
<li><strong>Level 1 warmup coverage.</strong> Debug staging into the final room triggers {warning_count} cold-shader guard warnings: the program count grows from 139 to 143. Stable room captures introduce zero new live programs. Reproduce the natural doorway route and cover the missing variants without inflating startup unnecessarily. The warnings are retained, not treated as a clean-console pass.</li></ol>
<img src="frame-pacing.png" alt="Level 2 frame interval over time for initial entry, warmed entry, paused background preparation, and the stock control"><p><a href="frame-pacing.svg">Vector chart</a>. Green dotted line: 60 Hz / 16.7 ms. Orange dashed line: severe-hitch threshold of 150 ms.</p>
<h2>Restart and resource stability</h2><div class="scroll"><table><tr><th>Level</th><th>Restarts</th><th>Programs min–max</th><th>Geometries min–max</th><th>Textures min–max</th><th>Observed heap MiB min–max</th></tr>{''.join(restarts)}</table></div>
<p>Four ordinary pause-menu restart cycles per level, with at least five seconds after input resumes, show zero growth in these renderer resource counts. The larger Level 2 scene naturally owns more geometry; counts drop on transition to Level 3. Restart checks preserve the same renderer instance and resident level; they do not reconstruct every asset. Heap values fluctuate with garbage collection and include instrumentation. Resource counts are not GPU allocation bytes. This is a bounded stability result, not a long-duration heap/GPU-memory leak proof.</p>
<h2>Build validation</h2><p>The clean production TypeScript/Vite build passed. Production layout and HTML/CSS reference validation passed for all 77 build files. Git diff is empty; the PDF remains the original untracked input. All benchmark-owned Chrome windows and preview servers were closed after their captures.</p><h2>Scope, exclusions and reproduction</h2><p>Production build of clean HEAD extracted into /tmp; the user-provided PDF is untouched. No tracked game code, dependencies or graphics defaults were changed. Temporary Node/Chrome tools and generated evidence remain local. The default game is instrumented through module routing to expose runtime composition roots; the shipped build is unchanged. Routing disables HTTP caching. Browser/driver/OS caches, clocks, temperature and AC/battery state were not controlled. Existing Firefox and desktop processes remained running; no concurrent builds, tests or GPU benchmark sessions ran during captures.</p>
<p>The formal lab protocol requires seven native scenarios × three passes, interaction verification, browser-cold/warm evidence and approved budgets. This session does not certify that protocol or a complete start-to-finish puzzle/combat/platform playthrough. Timing samples include genuine movement; observation runs are labelled distinctly. A Level 3 harness timeout in an earlier survey came from clicking before its arrival cinematic enabled input; later runs wait for input, then acquire pointer lock. The earlier 4.3-second Level 3 running-state time excludes the arrival and must not be called time-to-control.</p>
<details><summary>Rejected captures retained for audit</summary><ul>{''.join(invalid)}</ul></details>
<p>Start from the project root with Node 24.14.1 and the installed locked dependencies. The harness uses the temporary Chrome executable recorded in its source. Preserve the build and manifest under <code>artifacts/lab-benchmark/dist</code>.</p>
<pre>PROFILE_DIST=artifacts/lab-benchmark/dist PROFILE_LABEL=another-lab-run \\
PROFILE_WIDTH=1920 PROFILE_HEIGHT=1080 PROFILE_DPR=1 PROFILE_HEADLESS=0 \\
PROFILE_RUNS=1 PROFILE_KEY_MS=7000 PROFILE_RECORDER=1 \\
PROFILE_RESTARTS=1 PROFILE_ROOM_SET=long \\
node artifacts/lab-benchmark/profile-lab.mjs

node artifacts/lab-benchmark/summarize-lab.mjs [capture directory labels]
python3 artifacts/lab-benchmark/make-report.py</pre>
<p>Open observation runs use <code>PROFILE_SCOPE=beta PROFILE_OPEN_ROOM5=1 PROFILE_SKIP_ONE_SAMPLES=1 PROFILE_KEY_MS=2500</code>. The isolated preparation diagnostic uses <code>PROFILE_SCOPE=two PROFILE_PAUSE_BACKGROUND=1 PROFILE_KEY_MS=7000</code> without restarts or open-view overrides. A control omits the pause override. <a href="profile-lab.mjs">Diagnostic harness</a> · <a href="summarize-lab.mjs">Summary script</a> · <a href="summary.log">Numerical summary</a> · <a href="build.log">Build log</a>.</p></html>'''
(root/'report.html').write_text(body)
print(root/'report.html')
