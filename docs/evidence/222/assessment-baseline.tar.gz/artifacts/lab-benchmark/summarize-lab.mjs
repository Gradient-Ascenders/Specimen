import {readFile,writeFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {analyzeRecording} from '../../scripts/lib/performance-qualification.mjs';
const labels=process.argv.slice(2),result=[];
for(const label of labels){
 const root=path.resolve('artifacts/performance-overhaul',label);
 const raw=JSON.parse(await readFile(path.join(root,'raw.json'),'utf8'));
 const captures=[];
 for(const file of (await readdir(root)).filter(n=>n.endsWith('-flight.json'))){
  const flight=JSON.parse(await readFile(path.join(root,file),'utf8'));
  const report=analyzeRecording(flight);
  captures.push({file,viewport:flight.viewport,webgl:flight.webgl,summary:flight.summary,qualificationLifecycle:flight.qualification.lifecycle,...report});
 }
 const item={label,gitSha:raw.gitSha,buildManifest:raw.buildManifest,browserVersion:raw.browserVersion,protocol:raw.protocol,diagnosticOverrides:raw.diagnosticOverrides,rejectedCaptures:raw.rejectedCaptures,requestedGraphics:raw.requestedGraphics,cacheProtocol:raw.cacheProtocol,errors:raw.errors,failure:raw.failure,runs:raw.runs.map(r=>({run:r.run,bootMs:r.bootMs,readyMs:r.readyMs,playToControlMs:r.playToControlMs,twoTransitionMs:r.twoTransitionMs,threeTransitionMs:r.threeTransitionMs,restarts:r.restarts,profiles:r.profiles?.map(p=>({name:p.name,phases:p.phases,compiles:p.compiles,slowDraws:p.slowDraws})),rooms:r.rooms.filter(x=>x.frames).map(x=>({name:x.name,room:x.room,variant:x.variant,preparation:x.preparation,diagnostics:x.diagnostics,glError:x.glError,liveNewPrograms:x.frames.reduce((s,f)=>s+(f.liveNewPrograms??0),0),maxRender:Math.max(...x.frames.map(f=>f.render)),maxFixed:Math.max(...x.frames.map(f=>f.fixed)),stalls:x.frames.filter(f=>f.cadence>50).map(f=>({start:f.start,cadence:f.cadence,render:f.render,fixed:f.fixed,programs:f.programs,preparation:f.preparation}))}))})),captures};
 result.push(item);
 console.log(label,'loading seconds',item.runs.map(r=>[r.bootMs,r.twoTransitionMs,r.threeTransitionMs].map(v=>v&&+(v/1000).toFixed(2))),'errors',raw.errors.length,raw.failure??'');
 for(const c of captures) console.log(c.file,JSON.stringify({valid:c.valid,reasons:c.reasons,seconds:+(c.elapsedMs/1000).toFixed(1),fps:c.frame?.fps,p95:c.frame?.p95,p99:c.frame?.p99,low:c.frame?.onePercentLow,gpu:c.gpu?.mean,cpu:c.updateCpu?.mean,render:c.renderCpu?.mean,maxRender:c.renderCpu?.max,hitches:c.hitches,loss:c.simulation?.lostPercent}));
}
await writeFile('artifacts/lab-benchmark/results.json',JSON.stringify(result,null,2));
