import subprocess, pathlib, shutil, sys, json
root=pathlib.Path.cwd()
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
target=pathlib.Path('/tmp') / ('specimen-222-'+sha[:12])
target.mkdir(exist_ok=True)
archive=subprocess.Popen(['git','archive','HEAD'],stdout=subprocess.PIPE)
subprocess.run(['tar','-x','-C',str(target)],stdin=archive.stdout,check=True)
archive.stdout.close()
assert archive.wait()==0
if not (target/'.git').exists(): (target/'.git').symlink_to(root/'.git',target_is_directory=True)
(target/'node_modules').mkdir(exist_ok=True)
subprocess.run(['cp','-as',str(root/'node_modules')+'/.',str(target/'node_modules')],check=True)
subprocess.run(['npm','run','build'],cwd=target,check=True)
manifest=json.loads((target/'dist/build-manifest.json').read_text())
assert manifest['sha']==sha and not manifest['dirty'],manifest
out=root/'artifacts/lab-performance-222'/('dist-'+sha[:12])
shutil.copytree(target/'dist',out,dirs_exist_ok=True)
print(out.relative_to(root))
